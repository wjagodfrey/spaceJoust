Hector
======

Quite an interesting head

## Installation
* `clone`
* `npm install`

## Development
* `cake build`
* `cake start`
